package com.myorganizer.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

object ReminderNotifications {
    private const val CHANNEL_ID = "organizer_reminders"
    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Напоминания", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Личные напоминания органайзера"
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    fun schedule(context: Context, reminder: ReminderItem) {
        val intent = Intent(context, ReminderReceiver::class.java).putExtra("title", reminder.title).putExtra("id", reminder.id)
        val pending = PendingIntent.getBroadcast(context, reminder.id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.triggerAt, pending)
    }
    fun cancel(context: Context, reminder: ReminderItem) {
        val intent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(context, reminder.id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
    }

    /** Re-create all future alarms from the app's durable local store. */
    fun rescheduleFuture(context: Context) {
        val reminders = runCatching {
            val raw = context.getSharedPreferences("my_organizer_data", Context.MODE_PRIVATE)
                .getString("reminders", "[]")
            val array = org.json.JSONArray(raw)
            (0 until array.length()).map { index ->
                val item = array.getJSONObject(index)
                ReminderItem(item.optString("id"), item.optString("title"), item.optLong("triggerAt"))
            }
        }.getOrDefault(emptyList())
        val now = System.currentTimeMillis()
        reminders.filter { it.triggerAt > now && it.title.isNotBlank() }.forEach {
            schedule(context, it)
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderNotifications.createChannel(context)
        val title = intent.getStringExtra("title") ?: "Напоминание"
        val openApp = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentIntent = PendingIntent.getActivity(
            context, (intent.getStringExtra("id") ?: title).hashCode(), openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, "organizer_reminders")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Мой органайзер")
            .setContentText(title)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify((intent.getStringExtra("id") ?: title).hashCode(), notification)
    }
}

/** Re-create pending reminder alarms after the device finishes booting. */
class ReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action !in setOf(
                Intent.ACTION_BOOT_COMPLETED,
                Intent.ACTION_TIME_CHANGED,
                Intent.ACTION_TIMEZONE_CHANGED
            )) return
        val stored = runCatching {
            val array = org.json.JSONArray(
                context.getSharedPreferences("my_organizer_data", Context.MODE_PRIVATE)
                    .getString("reminders", "[]")
            )
            (0 until array.length()).map { index ->
                val item = array.getJSONObject(index)
                ReminderItem(
                    id = item.optString("id"),
                    title = item.optString("title"),
                    triggerAt = item.optLong("triggerAt")
                )
            }
        }.getOrDefault(emptyList())

        val now = System.currentTimeMillis()
        stored.filter { it.triggerAt > now }.forEach {
            ReminderNotifications.schedule(context, it)
        }
    }
}
