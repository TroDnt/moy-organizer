package com.myorganizer.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Compact home-screen card showing today's and the next day's shift. */
class ShiftWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateOne(context, manager, it) }
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ShiftWidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it) }
        }

        private fun shiftFor(context: Context, date: LocalDate): String? {
            val prefs = context.getSharedPreferences("my_organizer_data", Context.MODE_PRIVATE)
            val manual = runCatching {
                JSONObject(prefs.getString("shifts", "{}") ?: "{}").optString(date.toString(), "")
            }.getOrDefault("").takeIf { it.isNotBlank() }
            if (manual != null) return manual
            return runCatching {
                val cycle = JSONObject(prefs.getString("shift_cycle", "{}") ?: "{}")
                val pattern = JSONArray(cycle.optString("pattern", "[]"))
                if (pattern.length() == 0) return null
                val anchor = LocalDate.parse(cycle.optString("anchorDate"))
                val index = Math.floorMod(java.time.temporal.ChronoUnit.DAYS.between(anchor, date), pattern.length().toLong()).toInt()
                pattern.getString(index)
            }.getOrNull()
        }

        private fun label(shift: String?): String = when (shift) {
            "День" -> "☀  Дневная смена"
            "Ночь" -> "☾  Ночная смена"
            "Выходной" -> "✓  Выходной"
            else -> "Смена не задана"
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val today = LocalDate.now()
            val tomorrow = today.plusDays(1)
            val locale = Locale("ru", "RU")
            val views = RemoteViews(context.packageName, R.layout.widget_shift)
            views.setTextViewText(R.id.shift_widget_date,
                today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", locale)))
            views.setTextViewText(R.id.shift_widget_today, label(shiftFor(context, today)))
            views.setTextViewText(R.id.shift_widget_next_date,
                "Завтра · " + tomorrow.format(DateTimeFormatter.ofPattern("d MMMM", locale)))
            views.setTextViewText(R.id.shift_widget_next, label(shiftFor(context, tomorrow)))
            val open = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pending = PendingIntent.getActivity(context, 8300 + id, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.shift_widget_root, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
