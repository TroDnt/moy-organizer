package com.myorganizer.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject

class TasksWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateOne(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE) {
            val taskId = intent.getStringExtra(EXTRA_TASK_ID) ?: return
            val prefs = context.getSharedPreferences("my_organizer_data", Context.MODE_PRIVATE)
            val tasks = JSONArray(prefs.getString("tasks", "[]"))
            for (i in 0 until tasks.length()) {
                val task = tasks.getJSONObject(i)
                if (task.optString("id") == taskId) {
                    task.put("done", !task.optBoolean("done"))
                    break
                }
            }
            prefs.edit().putString("tasks", tasks.toString()).apply()
            updateAll(context)
        }
    }

    companion object {
        private const val ACTION_TOGGLE = "com.myorganizer.app.TOGGLE_WIDGET_TASK"
        private const val EXTRA_TASK_ID = "task_id"
        private val checkIds = intArrayOf(R.id.task1_check, R.id.task2_check, R.id.task3_check)
        private val textIds = intArrayOf(R.id.task1_text, R.id.task2_text, R.id.task3_text)

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, TasksWidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_tasks)
            val prefs = context.getSharedPreferences("my_organizer_data", Context.MODE_PRIVATE)
            val tasks = runCatching {
                val array = JSONArray(prefs.getString("tasks", "[]"))
                (0 until array.length()).map { array.getJSONObject(it) }
            }.getOrDefault(emptyList())
            val completed = tasks.count { it.optBoolean("done") }
            views.setTextViewText(R.id.widget_subtitle, "$completed из ${tasks.size} выполнено · нажми на задачу")
            repeat(3) { index ->
                val task = tasks.getOrNull(index)
                if (task == null) {
                    views.setTextViewText(checkIds[index], "")
                    views.setTextViewText(textIds[index], "Нет задачи")
                    views.setOnClickPendingIntent(checkIds[index], null)
                    views.setOnClickPendingIntent(textIds[index], null)
                } else {
                    val done = task.optBoolean("done")
                    val id = task.optString("id")
                    views.setTextViewText(checkIds[index], if (done) "✓" else "○")
                    views.setTextColor(checkIds[index], if (done) 0xFF34D399.toInt() else 0xFFA78BFA.toInt())
                    views.setTextViewText(textIds[index], task.optString("title"))
                    val click = Intent(context, TasksWidgetProvider::class.java).apply {
                        action = ACTION_TOGGLE
                        putExtra(EXTRA_TASK_ID, id)
                        data = android.net.Uri.parse("organizer-task:$widgetId:$id")
                    }
                    val pending = PendingIntent.getBroadcast(context, (widgetId * 31 + index), click,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    views.setOnClickPendingIntent(checkIds[index], pending)
                    views.setOnClickPendingIntent(textIds[index], pending)
                }
            }
            manager.updateAppWidget(widgetId, views)
        }
    }
}
