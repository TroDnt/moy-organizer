package com.myorganizer.app

import android.content.Context
import android.os.Bundle
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import java.util.Calendar
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.UUID

private val bg = Color(0xFF111827)
private val panel = Color(0xFF1F2937)
private val accent = Color(0xFF8B5CF6)
private val muted = Color(0xFF9CA3AF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
        ReminderNotifications.createChannel(this)
        ReminderNotifications.rescheduleFuture(this)
        setContent { OrganizerApp(this) }
    }
}

data class TaskItem(val id: String = UUID.randomUUID().toString(), val title: String, val done: Boolean = false, val dueDate: String = "", val priority: String = "Обычный")
data class NoteItem(val id: String = UUID.randomUUID().toString(), val text: String, val folder: String = "Личное", val pinned: Boolean = false)
data class ReminderItem(val id: String = UUID.randomUUID().toString(), val title: String, val triggerAt: Long)
data class ShiftCycle(val anchorDate: String = LocalDate.now().toString(), val pattern: List<String> = emptyList())

fun shiftForDate(date: LocalDate, overrides: Map<String, String>, cycle: ShiftCycle): String? {
    overrides[date.toString()]?.let { return it }
    if (cycle.pattern.isEmpty()) return null
    val anchor = runCatching { LocalDate.parse(cycle.anchorDate) }.getOrNull() ?: return null
    val index = Math.floorMod(java.time.temporal.ChronoUnit.DAYS.between(anchor, date), cycle.pattern.size.toLong()).toInt()
    return cycle.pattern[index]
}

private object LocalStore {
    private const val PREFS = "my_organizer_data"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun loadTasks(context: Context): List<TaskItem> = runCatching {
        val array = JSONArray(prefs(context).getString("tasks", "[]"))
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            TaskItem(o.optString("id", UUID.randomUUID().toString()), o.optString("title"), o.optBoolean("done"), o.optString("dueDate", ""), o.optString("priority", "Обычный"))
        }
    }.getOrDefault(emptyList())

    fun saveTasks(context: Context, tasks: List<TaskItem>) {
        val array = JSONArray()
        tasks.forEach { array.put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done).put("dueDate", it.dueDate).put("priority", it.priority)) }
        prefs(context).edit().putString("tasks", array.toString()).apply()
    }

    fun loadNotes(context: Context): List<NoteItem> = runCatching {
        val array = JSONArray(prefs(context).getString("notes", "[]"))
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            NoteItem(o.optString("id", UUID.randomUUID().toString()), o.optString("text"), o.optString("folder", "Личное"), o.optBoolean("pinned", false))
        }
    }.getOrDefault(emptyList())

    fun saveNotes(context: Context, notes: List<NoteItem>) {
        val array = JSONArray()
        notes.forEach { array.put(JSONObject().put("id", it.id).put("text", it.text).put("folder", it.folder).put("pinned", it.pinned)) }
        prefs(context).edit().putString("notes", array.toString()).apply()
    }

    fun loadReminders(context: Context): List<ReminderItem> = runCatching {
        val array = JSONArray(prefs(context).getString("reminders", "[]"))
        (0 until array.length()).map { i -> val o = array.getJSONObject(i); ReminderItem(o.optString("id"), o.optString("title"), o.optLong("triggerAt")) }
    }.getOrDefault(emptyList())

    fun saveReminders(context: Context, reminders: List<ReminderItem>) {
        val array = JSONArray()
        reminders.forEach { array.put(JSONObject().put("id", it.id).put("title", it.title).put("triggerAt", it.triggerAt)) }
        prefs(context).edit().putString("reminders", array.toString()).apply()
    }

    fun loadShifts(context: Context): Map<String, String> = runCatching {
        val o = JSONObject(prefs(context).getString("shifts", "{}"))
        o.keys().asSequence().associateWith { o.getString(it) }
    }.getOrDefault(emptyMap())

    fun saveShifts(context: Context, shifts: Map<String, String>) {
        val o = JSONObject()
        shifts.forEach { (date, shift) -> o.put(date, shift) }
        prefs(context).edit().putString("shifts", o.toString()).apply()
    }

    fun loadShiftCycle(context: Context): ShiftCycle = runCatching {
        val o = JSONObject(prefs(context).getString("shift_cycle", "{}"))
        val pattern = JSONArray(o.optString("pattern", "[]"))
        ShiftCycle(o.optString("anchorDate", LocalDate.now().toString()), (0 until pattern.length()).map { pattern.getString(it) })
    }.getOrDefault(ShiftCycle())

    fun saveShiftCycle(context: Context, cycle: ShiftCycle) {
        val pattern = JSONArray()
        cycle.pattern.forEach { pattern.put(it) }
        val value = JSONObject().put("anchorDate", cycle.anchorDate).put("pattern", pattern)
        prefs(context).edit().putString("shift_cycle", value.toString()).apply()
    }

    // A portable, versioned backup containing every user data collection.
    fun createBackup(context: Context): String {
        val p = prefs(context)
        val data = JSONObject()
        listOf("tasks", "notes", "reminders", "shifts", "shift_cycle").forEach { key ->
            val raw = p.getString(key, null) ?: when (key) {
                "tasks", "notes", "reminders" -> "[]"
                "shifts", "shift_cycle" -> "{}"
                else -> "{}"
            }
            data.put(key, if (raw.startsWith("[")) JSONArray(raw) else JSONObject(raw))
        }
        return JSONObject().put("format", "my-organizer-backup").put("version", 1)
            .put("createdAt", System.currentTimeMillis()).put("data", data).toString(2)
    }

    fun restoreBackup(context: Context, json: String): Boolean = runCatching {
        val root = JSONObject(json)
        require(root.optString("format") == "my-organizer-backup") { "Это не резервная копия «Моего органайзера»" }
        require(root.optInt("version") == 1) { "Версия резервной копии не поддерживается" }
        val data = root.getJSONObject("data")
        val tasks = data.getJSONArray("tasks")
        val notes = data.getJSONArray("notes")
        val reminders = data.getJSONArray("reminders")
        val shifts = data.getJSONObject("shifts")
        val cycle = data.getJSONObject("shift_cycle")
        // Validate every collection before replacing existing data.
        for (i in 0 until tasks.length()) require(tasks.getJSONObject(i).has("title"))
        for (i in 0 until notes.length()) require(notes.getJSONObject(i).has("text"))
        for (i in 0 until reminders.length()) require(reminders.getJSONObject(i).has("triggerAt"))
        val editor = prefs(context).edit()
            .putString("tasks", tasks.toString())
            .putString("notes", notes.toString())
            .putString("reminders", reminders.toString())
            .putString("shifts", shifts.toString())
            .putString("shift_cycle", cycle.toString())
        editor.commit()
    }.getOrDefault(false)
}

@Composable
fun OrganizerApp(context: Context) {
    var section by remember { mutableStateOf("Главная") }
    var taskText by remember { mutableStateOf("") }
    var noteText by remember { mutableStateOf("") }
    var noteFolder by remember { mutableStateOf("Личное") }
    val tasks = remember { mutableStateListOf<TaskItem>().apply { addAll(LocalStore.loadTasks(context)) } }
    val notes = remember { mutableStateListOf<NoteItem>().apply { addAll(LocalStore.loadNotes(context)) } }
    val shifts = remember { mutableStateMapOf<String, String>().apply { putAll(LocalStore.loadShifts(context)) } }
    var shiftCycle by remember { mutableStateOf(LocalStore.loadShiftCycle(context)) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    val reminders = remember { mutableStateListOf<ReminderItem>().apply { addAll(LocalStore.loadReminders(context)) } }

    LaunchedEffect(tasks.toList()) { LocalStore.saveTasks(context, tasks.toList()); TasksWidgetProvider.updateAll(context) }
    LaunchedEffect(notes.toList()) { LocalStore.saveNotes(context, notes.toList()) }
    LaunchedEffect(shifts.toMap()) { LocalStore.saveShifts(context, shifts.toMap()); CalendarWidgetProvider.updateAll(context); ShiftWidgetProvider.updateAll(context) }
    LaunchedEffect(shiftCycle) { LocalStore.saveShiftCycle(context, shiftCycle); CalendarWidgetProvider.updateAll(context); ShiftWidgetProvider.updateAll(context) }
    LaunchedEffect(reminders.toList()) { LocalStore.saveReminders(context, reminders.toList()) }

    var backupMessage by remember { mutableStateOf<String?>(null) }
    val exportBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            val result = runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(LocalStore.createBackup(context)) } ?: error("Не удалось открыть файл") }
            backupMessage = if (result.isSuccess) "Резервная копия сохранена" else "Не удалось сохранить копию"
        }
    }
    val importBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val result = runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Не удалось прочитать файл") }
            val restored = result.getOrNull()?.let { LocalStore.restoreBackup(context, it) } == true
            if (restored) {
                // Remove pending alarms from the current data set before scheduling restored reminders.
                reminders.forEach { ReminderNotifications.cancel(context, it) }
                tasks.clear(); tasks.addAll(LocalStore.loadTasks(context))
                notes.clear(); notes.addAll(LocalStore.loadNotes(context))
                reminders.clear(); reminders.addAll(LocalStore.loadReminders(context))
                shifts.clear(); shifts.putAll(LocalStore.loadShifts(context))
                shiftCycle = LocalStore.loadShiftCycle(context)
                reminders.forEach { if (it.triggerAt > System.currentTimeMillis()) ReminderNotifications.schedule(context, it) }
                TasksWidgetProvider.updateAll(context); CalendarWidgetProvider.updateAll(context); ShiftWidgetProvider.updateAll(context)
                backupMessage = "Данные восстановлены"
            } else backupMessage = "Файл не распознан или повреждён. Старые данные не изменены."
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = bg, surface = panel, primary = accent)) {
        Scaffold(containerColor = bg, bottomBar = {
            NavigationBar(containerColor = panel) {
                listOf("Главная" to Icons.Default.Home, "Задачи" to Icons.Default.CheckCircle, "Календарь" to Icons.Default.CalendarMonth, "Заметки" to Icons.Default.EditNote, "Напоминания" to Icons.Default.Notifications).forEach { (name, icon) ->
                    NavigationBarItem(selected = section == name, onClick = { section = name }, icon = { Icon(icon, null) }, label = { Text(name) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = accent, selectedTextColor = Color.White, indicatorColor = bg, unselectedIconColor = muted, unselectedTextColor = muted))
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp, vertical = 12.dp)) {
                when (section) {
                    "Главная" -> HomeScreen(tasks, shiftForDate(LocalDate.now(), shifts, shiftCycle) ?: "Не задана", { shifts[LocalDate.now().toString()] = it }, { section = it }, notes.size, { exportBackup.launch("MyOrganizer_backup.json") }, { importBackup.launch(arrayOf("application/json", "text/*", "application/octet-stream")) }, backupMessage, { backupMessage = null })
                    "Задачи" -> TasksScreen(tasks, taskText, { taskText = it }, { priority, dueDate -> if (taskText.isNotBlank()) { tasks.add(0, TaskItem(title = taskText.trim(), priority = priority, dueDate = dueDate)); taskText = "" } })
                    "Календарь" -> CalendarScreen(context, month, { month = it }, shifts, shiftCycle, { date, shift -> shifts[date.toString()] = shift }, { shiftCycle = it })
                    "Заметки" -> NotesScreen(notes, noteText, { noteText = it }, noteFolder, { noteFolder = it }, { if (noteText.isNotBlank()) { notes.add(0, NoteItem(text = noteText.trim(), folder = noteFolder)); noteText = "" } })
                    "Напоминания" -> RemindersScreen(context, reminders)
                }
            }
        }
    }
}

@Composable
fun HomeScreen(tasks: List<TaskItem>, shift: String, setShift: (String) -> Unit, navigate: (String) -> Unit, noteCount: Int, exportBackup: () -> Unit, importBackup: () -> Unit, backupMessage: String?, dismissBackupMessage: () -> Unit) {
    val today = LocalDate.now()
    Text("МОЙ ОРГАНАЙЗЕР", color = muted, style = MaterialTheme.typography.labelLarge)
    Spacer(Modifier.height(6.dp))
    Text(today.format(DateTimeFormatter.ofPattern("d MMMM")), color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    Text(today.format(DateTimeFormatter.ofPattern("EEEE")), color = muted)
    Spacer(Modifier.height(10.dp))
    Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CloudSync, null, tint = accent); Spacer(Modifier.width(8.dp)); Text("Резервная копия", color = Color.White, fontWeight = FontWeight.SemiBold) }
            Text("Сохрани или восстанови заметки, задачи, напоминания и график смен.", color = muted, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = exportBackup, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(5.dp)); Text("Сохранить") }
                OutlinedButton(onClick = importBackup, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(5.dp)); Text("Восстановить") }
            }
            if (backupMessage != null) { Text(backupMessage, color = if (backupMessage.contains("не удалось") || backupMessage.contains("не распознан")) Color(0xFFFCA5A5) else Color(0xFF6EE7B7), style = MaterialTheme.typography.bodySmall); TextButton(onClick = dismissBackupMessage) { Text("Закрыть") } }
        }
    }
    Spacer(Modifier.height(10.dp))
    Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("МОЯ СМЕНА", color = muted, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(8.dp))
            Text(shift, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(top = 12.dp)) {
                listOf("День", "Ночь", "Выходной").forEach { value ->
                    FilterChip(selected = shift == value, onClick = { setShift(value) }, label = { Text(value) })
                }
            }
        }
    }
    Spacer(Modifier.height(16.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        QuickCard("Задачи", "${tasks.count { it.done }} / ${tasks.size} выполнено", Icons.Default.CheckCircle, Modifier.weight(1f)) { navigate("Задачи") }
        QuickCard("Заметки", "$noteCount записей", Icons.Default.EditNote, Modifier.weight(1f)) { navigate("Заметки") }
    }
    Spacer(Modifier.height(16.dp))
    Row(verticalAlignment = Alignment.CenterVertically) { Text("На сегодня", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("Все задачи", color = accent, modifier = Modifier.clickable { navigate("Задачи") }) }
    Spacer(Modifier.height(8.dp))
    tasks.take(5).forEach { task ->
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(panel, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (task.done) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, null, tint = if (task.done) Color(0xFF34D399) else muted)
            Spacer(Modifier.width(10.dp)); Text(task.title, color = if (task.done) muted else Color.White)
        }
    }
    if (tasks.isEmpty()) Text("Пока задач нет. Добавь первую — и она появится здесь.", color = muted)
}

@Composable
fun QuickCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, click: () -> Unit) {
    Card(modifier.clickable(onClick = click), colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) { Icon(icon, null, tint = accent); Spacer(Modifier.height(8.dp)); Text(title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(subtitle, color = muted, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun TasksScreen(tasks: MutableList<TaskItem>, input: String, onInput: (String) -> Unit, add: (String, String) -> Unit) {
    var priority by remember { mutableStateOf("Обычный") }
    var dueDate by remember { mutableStateOf("") }
    var priorityMenu by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<TaskItem?>(null) }
    var editedTitle by remember { mutableStateOf("") }
    var editedPriority by remember { mutableStateOf("Обычный") }
    var editedDueDate by remember { mutableStateOf("") }
    var taskFilter by remember { mutableStateOf("Все") }
    val dateFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy")
    val datePickerContext = androidx.compose.ui.platform.LocalContext.current

    fun chooseDate(initial: String, onPicked: (String) -> Unit) {
        val initialDate = runCatching { if (initial.isBlank()) LocalDate.now() else LocalDate.parse(initial) }.getOrDefault(LocalDate.now())
        DatePickerDialog(
            datePickerContext,
            { _, year, month, day -> onPicked(LocalDate.of(year, month + 1, day).toString()) },
            initialDate.year, initialDate.monthValue - 1, initialDate.dayOfMonth
        ).show()
    }

    Text("Задачи", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(input, onInput, modifier = Modifier.weight(1f), placeholder = { Text("Новая задача") }, singleLine = true)
        IconButton(onClick = { if (input.isNotBlank()) { add(priority, dueDate); priority = "Обычный"; dueDate = "" } }) { Icon(Icons.Default.AddCircle, "Добавить", tint = accent) }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box {
            OutlinedButton(onClick = { priorityMenu = true }) { Text("Приоритет: $priority") }
            DropdownMenu(expanded = priorityMenu, onDismissRequest = { priorityMenu = false }) {
                listOf("Низкий", "Обычный", "Высокий").forEach { value ->
                    DropdownMenuItem(text = { Text(value) }, onClick = { priority = value; priorityMenu = false })
                }
            }
        }
        OutlinedButton(onClick = { chooseDate(dueDate) { dueDate = it } }) {
            Icon(Icons.Default.CalendarMonth, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text(if (dueDate.isBlank()) "Срок" else LocalDate.parse(dueDate).format(dateFormatter))
        }
        if (dueDate.isNotBlank()) TextButton(onClick = { dueDate = "" }) { Text("Сбросить") }
    }
    Text("Нажми на задачу, чтобы изменить её", color = muted, style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("Все", "Активные", "Готовые").forEach { value ->
            FilterChip(selected = taskFilter == value, onClick = { taskFilter = value }, label = { Text(value) })
        }
    }
    val visibleTasks = tasks.filter { task ->
        when (taskFilter) {
            "Активные" -> !task.done
            "Готовые" -> task.done
            else -> true
        }
    }
    val priorityRank: (String) -> Int = { value -> when (value) { "Высокий" -> 0; "Обычный" -> 1; else -> 2 } }
    val ordered = visibleTasks.sortedWith(
        compareBy<TaskItem> { it.done }
            .thenBy { if (it.dueDate.isBlank()) "9999-99-99" else it.dueDate }
            .thenBy { priorityRank(it.priority) }
    )
    if (ordered.isEmpty()) {
        Text(if (taskFilter == "Готовые") "Пока нет выполненных задач." else "Здесь пока пусто. Добавь задачу выше.", color = muted, modifier = Modifier.padding(top = 14.dp))
    }
    LazyColumn { items(ordered, key = { it.id }) { task ->
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(panel, RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = task.done, onCheckedChange = { checked -> val index = tasks.indexOfFirst { it.id == task.id }; if (index >= 0) tasks[index] = task.copy(done = checked) }, colors = CheckboxDefaults.colors(checkedColor = accent))
            Column(Modifier.weight(1f).clickable { editing = task; editedTitle = task.title; editedPriority = task.priority; editedDueDate = task.dueDate }) {
                Text(task.title, color = if (task.done) muted else Color.White)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${task.priority} приоритет", color = when (task.priority) { "Высокий" -> Color(0xFFF87171); "Низкий" -> muted; else -> accent }, style = MaterialTheme.typography.labelSmall)
                    if (task.dueDate.isNotBlank()) {
                        val isOverdue = !task.done && runCatching { LocalDate.parse(task.dueDate).isBefore(LocalDate.now()) }.getOrDefault(false)
                        Text(
                            (if (isOverdue) "Просрочено · " else "До ") + runCatching { LocalDate.parse(task.dueDate).format(dateFormatter) }.getOrDefault(task.dueDate),
                            color = if (isOverdue) Color(0xFFF87171) else muted,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
            IconButton(onClick = { tasks.removeAll { it.id == task.id } }) { Icon(Icons.Default.DeleteOutline, "Удалить", tint = muted) }
        }
    } }
    if (editing != null) {
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Изменить задачу") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(editedTitle, { editedTitle = it }, label = { Text("Название") }, singleLine = true)
                    Text("Приоритет")
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("Низкий", "Обычный", "Высокий").forEach { value -> FilterChip(selected = editedPriority == value, onClick = { editedPriority = value }, label = { Text(value) }) }
                    }
                    OutlinedButton(onClick = { chooseDate(editedDueDate) { editedDueDate = it } }) { Text(if (editedDueDate.isBlank()) "Указать срок" else "Срок: ${LocalDate.parse(editedDueDate).format(dateFormatter)}") }
                    if (editedDueDate.isNotBlank()) TextButton(onClick = { editedDueDate = "" }) { Text("Убрать срок") }
                }
            },
            confirmButton = { TextButton(onClick = { val old = editing!!; val index = tasks.indexOfFirst { it.id == old.id }; if (index >= 0 && editedTitle.isNotBlank()) tasks[index] = old.copy(title = editedTitle.trim(), priority = editedPriority, dueDate = editedDueDate); editing = null }) { Text("Сохранить") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Отмена") } }
        )
    }
}

@Composable
fun NotesScreen(notes: MutableList<NoteItem>, input: String, onInput: (String) -> Unit, folder: String, onFolder: (String) -> Unit, add: () -> Unit) {
    var folderMenu by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var editingNote by remember { mutableStateOf<NoteItem?>(null) }
    var editedText by remember { mutableStateOf("") }
    Text("Заметки", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Поиск по заметкам") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) })
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(input, onInput, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Новая заметка...") }, minLines = 3)
    Box {
        OutlinedButton(onClick = { folderMenu = true }) { Icon(Icons.Default.Folder, null); Spacer(Modifier.width(6.dp)); Text(folder); Icon(Icons.Default.ArrowDropDown, null) }
        DropdownMenu(expanded = folderMenu, onDismissRequest = { folderMenu = false }) {
            listOf("Личное", "Работа", "Покупки", "Идеи", "Документы").forEach { value -> DropdownMenuItem(text = { Text(value) }, onClick = { onFolder(value); folderMenu = false }) }
        }
    }
    Button(onClick = add, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text("Сохранить заметку") }
    Spacer(Modifier.height(8.dp))
    val filtered = notes.filter { it.text.contains(search, ignoreCase = true) || it.folder.contains(search, ignoreCase = true) }.sortedWith(compareByDescending<NoteItem> { it.pinned })
    LazyColumn {
        items(filtered, key = { it.id }) { note ->
            Card(colors = CardDefaults.cardColors(containerColor = panel), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { editingNote = note; editedText = note.text }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(note.folder.uppercase() + if (note.pinned) " · ЗАКРЕПЛЕНО" else "", color = accent, style = MaterialTheme.typography.labelSmall); Spacer(Modifier.height(4.dp)); Text(note.text, color = Color.White, maxLines = 4) }
                    IconButton(onClick = { val index = notes.indexOfFirst { it.id == note.id }; if (index >= 0) notes[index] = note.copy(pinned = !note.pinned) }) { Icon(if (note.pinned) Icons.Default.PushPin else Icons.Default.PushPin, if (note.pinned) "Открепить" else "Закрепить", tint = if (note.pinned) accent else muted) }
                    IconButton(onClick = { notes.removeAll { it.id == note.id } }) { Icon(Icons.Default.DeleteOutline, "Удалить", tint = muted) }
                }
            }
        }
    }
    if (editingNote != null) {
        AlertDialog(
            onDismissRequest = { editingNote = null },
            title = { Text("Редактировать заметку") },
            text = { OutlinedTextField(editedText, { editedText = it }, modifier = Modifier.fillMaxWidth(), minLines = 4) },
            confirmButton = { TextButton(onClick = { val old = editingNote!!; val index = notes.indexOfFirst { it.id == old.id }; if (index >= 0 && editedText.isNotBlank()) notes[index] = old.copy(text = editedText.trim()); editingNote = null }) { Text("Сохранить") } },
            dismissButton = { TextButton(onClick = { editingNote = null }) { Text("Отмена") } }
        )
    }
}

@Composable
fun CalendarScreen(context: Context, month: YearMonth, changeMonth: (YearMonth) -> Unit, shifts: Map<String, String>, cycle: ShiftCycle, setShift: (LocalDate, String) -> Unit, setCycle: (ShiftCycle) -> Unit) {
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var showCycleDialog by remember { mutableStateOf(false) }
    var cycleText by remember(cycle) { mutableStateOf(cycle.pattern.joinToString(", ")) }
    var anchorDate by remember(cycle) { mutableStateOf(runCatching { LocalDate.parse(cycle.anchorDate) }.getOrDefault(LocalDate.now())) }
    Text("Календарь", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { changeMonth(month.minusMonths(1)) }) { Icon(Icons.Default.ChevronLeft, null, tint = Color.White) }
        Text(month.format(DateTimeFormatter.ofPattern("LLLL yyyy")), color = Color.White, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
        IconButton(onClick = { changeMonth(month.plusMonths(1)) }) { Icon(Icons.Default.ChevronRight, null, tint = Color.White) }
    }
    val weekdays = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
    Row { weekdays.forEach { Text(it, modifier = Modifier.weight(1f), color = muted, style = MaterialTheme.typography.labelSmall) } }
    val offset = month.atDay(1).dayOfWeek.value - 1
    val cells = List(offset) { 0 } + (1..month.lengthOfMonth()).toList()
    cells.chunked(7).forEach { week ->
        Row(Modifier.fillMaxWidth()) {
            (week + List(7 - week.size) { 0 }).forEach { day ->
                val date = if (day > 0) month.atDay(day) else null
                val type = date?.let { shiftForDate(it, shifts, cycle) }
                val color = when (type) { "День" -> Color(0xFFB7791F); "Ночь" -> Color(0xFF6D4CC3); "Выходной" -> Color(0xFF18794E); else -> panel }
                Box(Modifier.weight(1f).padding(2.dp).height(42.dp).background(if (date == selectedDate) accent else color, RoundedCornerShape(8.dp)).clickable(enabled = date != null) { selectedDate = date!! }, contentAlignment = Alignment.Center) {
                    if (day > 0) Text(day.toString(), color = Color.White, fontWeight = if (date == LocalDate.now()) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
    Spacer(Modifier.height(14.dp))
    Text(selectedDate.format(DateTimeFormatter.ofPattern("d MMMM yyyy")), color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    Text("Выбери смену для этой даты", color = muted, style = MaterialTheme.typography.bodySmall)
    Text("По графику: ${shiftForDate(selectedDate, emptyMap(), cycle) ?: "не задана"}", color = muted, style = MaterialTheme.typography.bodySmall)
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(top = 8.dp)) {
        listOf("День", "Ночь", "Выходной").forEach { value -> FilterChip(selected = shifts[selectedDate.toString()] == value, onClick = { setShift(selectedDate, value) }, label = { Text(value) }) }
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("Автоматический цикл смен", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        TextButton(onClick = { showCycleDialog = true }) { Text("Настроить") }
    }
    Text(if (cycle.pattern.isEmpty()) "Цикл пока не настроен" else "${cycle.pattern.joinToString(" → ")} · начало ${anchorDate.format(DateTimeFormatter.ofPattern("d.MM.yyyy"))}", color = muted, style = MaterialTheme.typography.bodySmall)
    Text("Ручные отметки в календаре имеют приоритет над автоматическим циклом.", color = muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))

    if (showCycleDialog) {
        AlertDialog(
            onDismissRequest = { showCycleDialog = false },
            title = { Text("Настройка графика смен") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Перечисли смены по порядку через запятую. Например: День, Ночь, Выходной, Выходной", color = muted, style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(value = cycleText, onValueChange = { cycleText = it }, label = { Text("Повторяющийся цикл") }, modifier = Modifier.fillMaxWidth())
                    Text("Первый день цикла: ${anchorDate.format(DateTimeFormatter.ofPattern("d MMMM yyyy"))}", color = Color.White)
                    OutlinedButton(onClick = {
                        DatePickerDialog(context, { _, year, monthValue, day -> anchorDate = LocalDate.of(year, monthValue + 1, day) }, anchorDate.year, anchorDate.monthValue - 1, anchorDate.dayOfMonth).show()
                    }, modifier = Modifier.fillMaxWidth()) { Text("Выбрать дату начала") }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val allowed = setOf("День", "Ночь", "Выходной")
                    val pattern = cycleText.split(",", ";", "→").map { it.trim().replaceFirstChar { c -> c.uppercase() } }.filter { it in allowed }
                    setCycle(ShiftCycle(anchorDate.toString(), pattern))
                    showCycleDialog = false
                }) { Text("Сохранить") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { setCycle(ShiftCycle(anchorDate.toString(), emptyList())); showCycleDialog = false }) { Text("Отключить") }
                    TextButton(onClick = { showCycleDialog = false }) { Text("Отмена") }
                }
            }
        )
    }
    Text("Изменения сохраняются автоматически на телефоне.", color = muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 10.dp))
}


@Composable
fun RemindersScreen(context: Context, reminders: MutableList<ReminderItem>) {
    var title by remember { mutableStateOf("") }
    val activity = context as? ComponentActivity
    Text("Напоминания", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    Text("Уведомления придут в выбранные дату и время.", color = muted, style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(title, { title = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("О чём напомнить?") }, singleLine = true)
    Spacer(Modifier.height(8.dp))
    Button(onClick = {
        if (title.isNotBlank() && activity != null) {
            val now = Calendar.getInstance()
            DatePickerDialog(context, { _, year, month, day ->
                TimePickerDialog(context, { _, hour, minute ->
                    val cal = Calendar.getInstance().apply { set(year, month, day, hour, minute, 0); set(Calendar.MILLISECOND, 0) }
                    if (cal.timeInMillis > System.currentTimeMillis()) {
                        val item = ReminderItem(title = title.trim(), triggerAt = cal.timeInMillis)
                        reminders.add(0, item)
                        ReminderNotifications.schedule(context, item)
                        title = ""
                    }
                }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
            }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
        }
    }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = accent)) { Icon(Icons.Default.AddAlarm, null); Spacer(Modifier.width(8.dp)); Text("Выбрать дату и время") }
    Spacer(Modifier.height(12.dp))
    val formatter = remember { java.text.SimpleDateFormat("d MMM, HH:mm", java.util.Locale("ru")) }
    LazyColumn {
        items(reminders.sortedBy { it.triggerAt }, key = { it.id }) { reminder ->
            Card(colors = CardDefaults.cardColors(containerColor = panel), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Notifications, null, tint = accent)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) { Text(reminder.title, color = Color.White); Text(formatter.format(java.util.Date(reminder.triggerAt)), color = muted, style = MaterialTheme.typography.bodySmall) }
                    IconButton(onClick = { ReminderNotifications.cancel(context, reminder); reminders.removeAll { it.id == reminder.id } }) { Icon(Icons.Default.DeleteOutline, "Удалить", tint = muted) }
                }
            }
        }
    }
    if (reminders.isEmpty()) Text("Пока напоминаний нет.", color = muted)
}
