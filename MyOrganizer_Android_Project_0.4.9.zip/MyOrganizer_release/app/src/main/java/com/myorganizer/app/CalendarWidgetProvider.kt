package com.myorganizer.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

class CalendarWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateOne(context, manager, it) }
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, CalendarWidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val today = LocalDate.now()
            val prefs = context.getSharedPreferences("my_organizer_data", Context.MODE_PRIVATE)
            val shifts = runCatching { org.json.JSONObject(prefs.getString("shifts", "{}")) }.getOrNull()
            val manualShift = shifts?.optString(today.toString(), "")?.takeIf { it.isNotBlank() }
            val cycleShift = runCatching {
                val cycle = org.json.JSONObject(prefs.getString("shift_cycle", "{}"))
                val patternJson = org.json.JSONArray(cycle.optString("pattern", "[]"))
                if (patternJson.length() == 0) null else {
                    val anchor = LocalDate.parse(cycle.optString("anchorDate"))
                    val index = Math.floorMod(java.time.temporal.ChronoUnit.DAYS.between(anchor, today), patternJson.length().toLong()).toInt()
                    patternJson.getString(index)
                }
            }.getOrNull()
            val shift = manualShift ?: cycleShift ?: "Не задана"
            val views = RemoteViews(context.packageName, R.layout.widget_calendar)
            val locale = Locale("ru", "RU")
            views.setTextViewText(R.id.calendar_widget_month,
                YearMonth.from(today).format(DateTimeFormatter.ofPattern("LLLL yyyy", locale)).uppercase(locale))
            views.setTextViewText(R.id.calendar_widget_today,
                today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", locale)))
            views.setTextViewText(R.id.calendar_widget_shift, when (shift) {
                "День" -> "☀ День"
                "Ночь" -> "☾ Ночь"
                "Выходной" -> "✓ Выходной"
                else -> "Смена не задана"
            })
            val open = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pending = PendingIntent.getActivity(context, 7100 + id, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.calendar_widget_today, pending)
            views.setOnClickPendingIntent(R.id.calendar_widget_shift, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
